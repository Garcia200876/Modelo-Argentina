/* ==================================================
   MENU RESPONSIVO
================================================== */

const menuBtn = document.getElementById("menuBtn");
const navLinks = document.getElementById("navLinks");

if (menuBtn) {
    menuBtn.addEventListener("click", () => {
        navLinks.classList.toggle("open");
    });
}

document.querySelectorAll(".nav-links a").forEach(link => {
    link.addEventListener("click", () => {
        navLinks.classList.remove("open");
    });
});

/* ==================================================
   DARK MODE
================================================== */

const darkBtn = document.getElementById("darkBtn");

if (darkBtn) {
    darkBtn.addEventListener("click", () => {
        document.body.classList.toggle("dark");

        if (document.body.classList.contains("dark")) {
            darkBtn.innerHTML = "☀️";
            localStorage.setItem("theme", "dark");
        } else {
            darkBtn.innerHTML = "🌙";
            localStorage.setItem("theme", "light");
        }
    });
}

if (localStorage.getItem("theme") === "dark") {
    document.body.classList.add("dark");

    if (darkBtn) {
        darkBtn.innerHTML = "☀️";
    }
}

/* ==================================================
   CARROSSEL DE IMAGENS
================================================== */

const slides = document.getElementById("slides");
const slideItems = document.querySelectorAll(".slide");

let currentSlide = 0;

function updateCarousel() {
    if (!slides) return;

    slides.style.transform = `translateX(-${currentSlide * 100}%)`;
}

function nextSlide() {
    currentSlide++;

    if (currentSlide >= slideItems.length) {
        currentSlide = 0;
    }

    updateCarousel();
}

function prevSlide() {
    currentSlide--;

    if (currentSlide < 0) {
        currentSlide = slideItems.length - 1;
    }

    updateCarousel();
}

const nextBtn = document.getElementById("nextSlide");
const prevBtn = document.getElementById("prevSlide");

if (nextBtn) {
    nextBtn.addEventListener("click", nextSlide);
}

if (prevBtn) {
    prevBtn.addEventListener("click", prevSlide);
}

setInterval(() => {
    if (slideItems.length > 0) {
        nextSlide();
    }
}, 5000);

/* ==================================================
   TIMELINE ANIMADA
================================================== */

const timelineItems = document.querySelectorAll(".timeline-item");

function animateTimeline() {
    timelineItems.forEach(item => {
        const position = item.getBoundingClientRect().top;

        if (position < window.innerHeight - 120) {
            item.classList.add("show");
        }
    });
}

window.addEventListener("scroll", animateTimeline);
animateTimeline();

/* ==================================================
   CONTADORES ANIMADOS
================================================== */

const counters = document.querySelectorAll(".counter");

let countersStarted = false;

function startCounters() {
    if (countersStarted) return;

    const stats = document.getElementById("estatisticas");

    if (!stats) return;

    const position = stats.getBoundingClientRect().top;

    if (position < window.innerHeight - 100) {
        countersStarted = true;

        counters.forEach(counter => {
            const target = Number(counter.dataset.target);
            let value = 0;

            const increment = Math.max(1, Math.floor(target / 150));

            const timer = setInterval(() => {
                value += increment;

                if (value >= target) {
                    value = target;
                    clearInterval(timer);
                }

                counter.innerHTML = value.toLocaleString("pt-BR");
            }, 15);
        });
    }
}

window.addEventListener("scroll", startCounters);
startCounters();

/* ==================================================
   LOGIN COM DESCONTO
================================================== */

const loginBtn = document.getElementById("loginBtn");
const discountMsg = document.getElementById("discountMsg");

if (loginBtn) {
    loginBtn.addEventListener("click", () => {
        const nome = document.getElementById("nomeCliente").value;
        const email = document.getElementById("emailCliente").value;
        const destino = document.getElementById("destinoCliente").value;

        if (
            nome.trim() === "" ||
            email.trim() === "" ||
            destino.trim() === ""
        ) {
            discountMsg.style.display = "block";
            discountMsg.innerHTML = "Preencha todos os campos para liberar seu desconto.";
            return;
        }

        discountMsg.style.display = "block";

        discountMsg.innerHTML = `
            Bem-vindo, <strong>${nome}</strong>! 🇦🇷<br>
            Você ganhou <strong>15% OFF</strong> em pacotes para <strong>${destino}</strong>.<br>
            Cupom: <strong>ARGENTINA15</strong>
        `;
    });
}

/* ==================================================
   MAPA INTERATIVO
================================================== */

const mapInfo = document.getElementById("mapInfo");
const regionBtns = document.querySelectorAll(".regionBtn");

const regions = {
    buenosaires: {
        title: "Buenos Aires",
        text: "Capital argentina, famosa pelo tango, cafés históricos, futebol, política, arquitetura e vida cultural intensa."
    },

    patagonia: {
        title: "Patagônia",
        text: "Região de glaciares, lagos cristalinos, montanhas, neve, trilhas e paisagens impressionantes."
    },

    mendoza: {
        title: "Mendoza",
        text: "Principal região produtora de vinhos da Argentina, conhecida pelo Malbec, pela gastronomia e pela Cordilheira dos Andes."
    },

    iguazu: {
        title: "Cataratas do Iguaçu",
        text: "Uma das maiores maravilhas naturais da América do Sul, com quedas d'água grandiosas e biodiversidade."
    },

    ushuaia: {
        title: "Ushuaia",
        text: "Conhecida como a cidade do fim do mundo, localizada na Terra do Fogo, com paisagens frias e únicas."
    }
};

regionBtns.forEach(btn => {
    btn.addEventListener("click", () => {
        regionBtns.forEach(b => {
            b.classList.remove("active");
        });

        btn.classList.add("active");

        const region = regions[btn.dataset.region];

        if (region) {
            mapInfo.innerHTML = `
                <h3>${region.title}</h3>
                <p>${region.text}</p>
            `;
        }
    });
});

/* ==================================================
   RELÓGIO DE BUENOS AIRES
================================================== */

function updateClock() {
    const clock = document.getElementById("clock");

    if (!clock) return;

    const now = new Date();

    const time = new Intl.DateTimeFormat("pt-BR", {
        timeZone: "America/Argentina/Buenos_Aires",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        weekday: "long",
        day: "2-digit",
        month: "long",
        year: "numeric"
    }).format(now);

    clock.innerHTML = time;
}

setInterval(updateClock, 1000);
updateClock();

/* ==================================================
   CONTATO SIMULADO
================================================== */

const contactBtn = document.getElementById("contactBtn");
const contactMsg = document.getElementById("contactMsg");

if (contactBtn) {
    contactBtn.addEventListener("click", () => {
        contactMsg.style.display = "block";
    });
}

/* ==================================================
   BOTÃO VOLTAR AO TOPO
================================================== */

const toTop = document.getElementById("toTop");

window.addEventListener("scroll", () => {
    if (!toTop) return;

    if (window.scrollY > 500) {
        toTop.classList.add("show");
    } else {
        toTop.classList.remove("show");
    }
});

if (toTop) {
    toTop.addEventListener("click", () => {
        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    });
}

/* ==================================================
   ANIMAÇÕES AO SCROLL
================================================== */

const revealElements = document.querySelectorAll(".card, .stat, .mapa-info, .login-box");

function prepareReveal() {
    revealElements.forEach(el => {
        el.style.opacity = "0";
        el.style.transform = "translateY(40px)";
        el.style.transition = "all 0.8s ease";
    });
}

function revealOnScroll() {
    revealElements.forEach(el => {
        const position = el.getBoundingClientRect().top;

        if (position < window.innerHeight - 80) {
            el.style.opacity = "1";
            el.style.transform = "translateY(0)";
        }
    });
}

prepareReveal();

window.addEventListener("scroll", revealOnScroll);
revealOnScroll();

console.log("🇦🇷 Argentina Premium carregado com sucesso!");